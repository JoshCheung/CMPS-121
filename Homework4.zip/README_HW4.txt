Hello user, 
So the problem is, if you use an android phone, it will not prompt you for what app you should use. However, if you use an emulator it should. 
So please, use an emulator. I used a NEXUS 5X with a 7.1.1 updated OS/ API 22. 
   	       Thank you!
               	-J
