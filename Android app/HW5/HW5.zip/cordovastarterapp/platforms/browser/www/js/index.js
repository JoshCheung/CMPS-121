//Joshua Cheung
//Jotcheun
//CMPS121

var app = function() {

    var self = {};
    self.is_configured = false;

    Vue.config.silent = false; // show all warnings

    // Extends an array
    self.extend = function(a, b) {
        for (var i = 0; i < b.length; i++) {
            a.push(b[i]);
        }
    };

    // Enumerates an array.
    var enumerate = function(v) {
        var k=0;
        v.map(function(e) {e._idx = k++;});
    };

    // Initializes an attribute of an array of objects.
    var set_array_attribute = function (v, attr, x) {
        v.map(function (e) {e[attr] = x;});
    };

    self.initialize = function () {
        document.addEventListener('deviceready', self.ondeviceready, false);
    };

    self.ondeviceready = function () {
        // This callback is called once Cordova has finished
        // its own initialization.
        $("#vue-div").show(); // This is jQuery.
        self.is_configured = true;
    };

    self.reset = function () {
        self.vue.board = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0];
    };

     self.shuffle = function(i, j) {

        if(self.vue.board[(4*i+j)-1] == 0){
            //For black box in the left
            newVal = self.vue.board[4*i+j];
            Vue.set(self.vue.board, (4*i+j-1), newVal);
            Vue.set(self.vue.board, (4*i+j), 0);
       
        } 
        else if(self.vue.board[(4*i+j)-4] == 0){
            //For black box in the top
            newVal = self.vue.board[4*i+j];
            Vue.set(self.vue.board, (4*i+j-4), newVal);
            Vue.set(self.vue.board, (4*i+j), 0);
        }
        else if(self.vue.board[(4*i+j)+1] == 0){
            //For black box in the right
            newVal = self.vue.board[4*i+j];
            Vue.set(self.vue.board, (4*i+j+1), newVal);
            Vue.set(self.vue.board, (4*i+j), 0);
        }
        else if(self.vue.board[(4*i+j)+4] == 0){
            //For black box in the bottom
            newVal = self.vue.board[4*i+j];
            Vue.set(self.vue.board, (4*i+j+4), newVal);
            Vue.set(self.vue.board, (4*i+j), 0);
        }
    };

    self.scramble = function() {
        Shuffle(self.vue.board);
        var boolVal = isSolvable(self.vue.board);
        if(boolVal == false){       //If not solvable, calls shuffle again til the tiles can be solved 
            self.scramble();
        }
    };

    function Shuffle(array) {
        for (var i = array.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var temp = array[i];
            Vue.set(array,i, array[j]);
            Vue.set(array,j, array[i]);
            array[i] = array[j];
            array[j] = temp;
        }
    }


    function isSolvable(puzzle){
        var parity = 0;            //*********    Keep in mind that some code was taken from the stack overflow website!!    **************
        var g_Width = Math.sqrt(puzzle.length);
        var row = 0; 
        var blank = 0; // keeps track of the blank box

        for (var i = 0; i < puzzle.length; i++) {
            if(i % g_Width == 0){ 
                row++;
            }
            if(puzzle[i] == 0) { 
                blank = row;
                continue;
            }
            for(var j = i + 1; j < puzzle.length; j++) {
                if (puzzle[i] > puzzle[j] && puzzle[j] != 0) {
                    parity++;
                }
            }
        }

        if (g_Width % 2 == 0) { 
            if (blank % 2 == 0) { 
                
                return parity % 2 == 0;
            } else { 
               
                return parity % 2 != 0;
            }
        }
    }

    self.vue = new Vue({
        el: "#vue-div",
        delimiters: ['${', '}'],
        unsafeDelimiters: ['!{', '}'],
        data: {
            board: []
        },
        methods: {
            reset: self.reset,
            shuffle: self.shuffle,
            scramble: self.scramble
        }

    });

    self.reset();

    return self;
};

var APP = null;

// This will make everything accessible from the js console;
// for instance, self.x above would be accessible as APP.x
jQuery(function(){
    APP = app();
    APP.initialize();
});
